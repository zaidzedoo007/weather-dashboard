package com.weatherapp.presentation

import com.weatherapp.data.local.SharedPrefsHelper
import com.weatherapp.data.model.Main
import com.weatherapp.data.model.Weather
import com.weatherapp.data.model.WeatherResponse
import com.weatherapp.domain.repository.WeatherRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito.*
import org.mockito.kotlin.any
import org.mockito.kotlin.anyOrNull
import org.mockito.kotlin.mock

@OptIn(ExperimentalCoroutinesApi::class)
class WeatherViewModelTest {

    private lateinit var viewModel: WeatherViewModel
    private lateinit var repository: WeatherRepository
    private lateinit var mockPrefs: SharedPrefsHelper

    private val mockWeatherResponse = WeatherResponse(
        name = "Cairo",
        main = Main(temp = 28.0),
        weather = listOf(Weather(description = "Sunny", icon = "01d"))
    )

    private val apiKey = "FAKE_API_KEY"
    private val testDispatcher = StandardTestDispatcher()
    private val savedCities = mutableListOf<String>()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)

        repository = mock(WeatherRepository::class.java)
        mockPrefs = mock(SharedPrefsHelper::class.java)

        // Mock getRecentCities
        `when`(mockPrefs.getRecentCities()).thenAnswer {
            savedCities.toList()
        }

        // Mock saveLastCity
        doAnswer { invocation ->
            val city = invocation.arguments[0] as String
            savedCities.remove(city)
            savedCities.add(0, city)
            if (savedCities.size > 3) savedCities.removeAt(savedCities.lastIndex)
            null
        }.`when`(mockPrefs).saveRecentCity(anyString())

        viewModel = WeatherViewModel(repository, apiKey, mockPrefs)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `getWeather should emit Success and save to recent cities`() = runTest {
        `when`(repository.getWeather("Cairo", apiKey)).thenReturn(mockWeatherResponse)

        viewModel.getWeather("Cairo")
        testDispatcher.scheduler.advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state is WeatherUiState.Success)
        assertEquals("Cairo", (state as WeatherUiState.Success).data.name)

        val recent = viewModel.recentCities.value
        assertTrue(recent.contains("Cairo"))
    }

    @Test
    fun `getWeather should emit Error on failure`() = runTest {
        val errorMsg = "City not found"
        val expectedMsg = "Failed to fetch weather: $errorMsg"

        `when`(repository.getWeather("InvalidCity", apiKey))
            .thenThrow(RuntimeException(errorMsg))

        viewModel.getWeather("InvalidCity")
        testDispatcher.scheduler.advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state is WeatherUiState.Error)
        assertEquals(expectedMsg, (state as WeatherUiState.Error).message)
    }

    @Test
    fun `recent cities should only store max 3 and no duplicates`() = runTest {
        `when`(repository.getWeather(anyString(), anyString())).thenReturn(mockWeatherResponse)

        listOf("Paris", "London", "Cairo").forEach {
            viewModel.getWeather(it)
        }

        testDispatcher.scheduler.advanceUntilIdle()

        val recent = viewModel.recentCities.value
        assertEquals(3, recent.size)
        assertEquals("Cairo", recent.first())
    }
}