package com.weatherapp.presentation.ui.screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.weatherapp.data.local.SharedPrefsHelper
import com.weatherapp.presentation.WeatherViewModel
import com.weatherapp.presentation.ui.theme.WeatherAppTheme


class MainScreen : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val context = LocalContext.current
            val apiKey = "211411f335693f067077f3fc1e7a3387"
            val viewModel = remember {
                WeatherViewModel(
                    com.weatherapp.domain.repository.WeatherRepository(
                        com.weatherapp.data.remote.WeatherApiProvider.provideApi()
                    ),
                    apiKey,
                    SharedPrefsHelper(context)
                )
            }
            val recentCities by viewModel.recentCities.collectAsState()
            WeatherAppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    WeatherSearchScreen(
                        uiState = viewModel.uiState.collectAsState().value,
                        onSearch = viewModel::getWeather,
                        recentCities = recentCities
                    )
                }
            }
        }
    }
}
