package com.weatherapp.presentation.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.weatherapp.data.model.Weather
import com.weatherapp.data.model.WeatherResponse
import com.weatherapp.presentation.WeatherUiState
import com.weatherapp.presentation.ui.theme.WeatherAppTheme
import com.weatherapp.data.model.Main
import androidx.compose.foundation.Image
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import com.weatherapp.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherSearchScreen(
    uiState: WeatherUiState,
    onSearch: (String) -> Unit,
    recentCities: List<String>
) {
    var city by remember { mutableStateOf(TextFieldValue("")) }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(uiState) {
        if (uiState is WeatherUiState.Success) {
            city = TextFieldValue("")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.weather_dashboard)) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TextField(
                value = city,
                onValueChange = { city = it },
                placeholder = { Text(stringResource(R.string.enter_a_city_and_press_search)) },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                onSearch(city.text)
                keyboardController?.hide()
            }) {
                Text("Search")
            }

            when (uiState) {
                is WeatherUiState.Success -> {
                    val data = uiState.data
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F7FA))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "City: ${data.name}", style = MaterialTheme.typography.titleLarge)
                            Text(text = "Temperature: ${data.main.temp} °C", style = MaterialTheme.typography.bodyLarge)
                            Text(text = "Condition: ${data.weather.firstOrNull()?.description ?: "N/A"}")
                            data.weather.firstOrNull()?.icon?.let { iconCode ->
                                val iconUrl = "https://openweathermap.org/img/wn/${iconCode}@2x.png"
                                Image(
                                    painter = rememberAsyncImagePainter(iconUrl),
                                    contentDescription = null,
                                    modifier = Modifier.size(64.dp)
                                )
                            }
                        }
                    }
                }
                else -> {}
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (recentCities.isNotEmpty()) {
                Text("Recent Searches:", style = MaterialTheme.typography.titleMedium)
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items = recentCities.take(3), key = { it }) { cityItem ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSearch(cityItem) },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F1F1))
                        ) {
                            Text(
                                text = cityItem,
                                modifier = Modifier
                                    .padding(12.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (uiState) {
                is WeatherUiState.Loading -> {
                    CircularProgressIndicator()
                }
                is WeatherUiState.Error -> {
                    Text(text = uiState.message, color = Color.Red)
                }
                WeatherUiState.Idle -> {
                    Text("")
                }
                else -> {}
            }
        }
    }
}

// Preview function for WeatherSearchScreen

@Preview(showBackground = true)
@Composable
fun WeatherSearchScreenPreview() {
    val mockData = WeatherResponse(
        name = "Preview City",
        main = Main(temp = 25.5),
        weather = listOf(Weather("Clear sky", "01d"))
    )
    WeatherAppTheme {
        WeatherSearchScreen(
            uiState = WeatherUiState.Success(mockData),
            onSearch = {},
            recentCities = listOf("Paris", "New York", "Cairo")
        )
    }
}