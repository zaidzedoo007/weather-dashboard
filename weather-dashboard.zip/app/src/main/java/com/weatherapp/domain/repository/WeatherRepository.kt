package com.weatherapp.domain.repository

import com.weatherapp.data.model.WeatherResponse
import com.weatherapp.data.remote.WeatherApi

open class WeatherRepository(private val api: WeatherApi) {
    suspend fun getWeather(city: String, apiKey: String): WeatherResponse {
        return api.getWeatherByCity(city, apiKey)
    }
}