package com.weatherapp.data.model

data class Main(val temp: Double)