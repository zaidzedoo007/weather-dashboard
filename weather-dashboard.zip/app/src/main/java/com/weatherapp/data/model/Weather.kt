package com.weatherapp.data.model

data class Weather(val description: String, val icon: String)