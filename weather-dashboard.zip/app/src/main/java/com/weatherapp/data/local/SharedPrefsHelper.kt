package com.weatherapp.data.local

import android.content.Context

class SharedPrefsHelper(context: Context) {
    private val prefs = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)

    fun saveRecentCity(city: String) {
        val current = getRecentCities().toMutableList()
        current.remove(city) // remove if it already exists
        current.add(0, city) // add to front
        if (current.size > 3) current.removeAt(current.lastIndex) // remove the oldest
        prefs.edit().putStringSet("recent_cities", current.toSet()).apply()
    }

    fun getRecentCities(): List<String> {
        return prefs.getStringSet("recent_cities", emptySet())?.toList() ?: emptyList()
    }
}