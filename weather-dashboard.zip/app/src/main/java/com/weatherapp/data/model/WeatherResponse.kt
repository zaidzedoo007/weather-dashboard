package com.weatherapp.data.model

data class WeatherResponse(
    val name: String,                 // City name
    val main: Main,                   // Temp object
    val weather: List<Weather>        // List of weather descriptions
)



